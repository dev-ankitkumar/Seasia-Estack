import RouteFiles from "./component/route/RouteFiles";
export default function App() {
  return <RouteFiles />;
}
