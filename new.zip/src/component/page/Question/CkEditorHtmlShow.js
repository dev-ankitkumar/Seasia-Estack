import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
export default function CkEditorHtmlShow(props) {
  return (
    <>
      <CKEditor
        editor={ClassicEditor}
        disabled
        data={props.data}
        config={
          ({ placeholder: "Enter Your Description..." },
          {
            toolbar: [],
          })
        }
        // placeholder="Enter Your Description"
        onReady={(editor) => {
          // You can store the "editor" and use when it is needed.
          // console.log("Editor is ready to use!", editor);
        }}
        onChange={(event, editor) => {
          editor.getData(props.data);
          //   setDescription(data);
        }}
        onBlur={(event, editor) => {
          // console.log("Blur.", editor);
        }}
        onFocus={(event, editor) => {
          // console.log("Focus.", editor);
        }}
      />
    </>
  );
}
