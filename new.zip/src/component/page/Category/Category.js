export default function Category() {
  return <div>Category</div>;
}
